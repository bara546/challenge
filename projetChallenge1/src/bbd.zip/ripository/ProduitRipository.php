<?php


namespace App\Ripository;

use App\Entity\Produit;
use PDO;
use PDOException;

class ProduitRipository
{
    private PDO $pdo;

    public function __construct()
    {
        try {
            $host = 'localhost';
            $dbname = 'Auchan';
            $user = 'postgres';
            $password = 'passer';

            $dsn = "pgsql:host=$host;dbname=$dbname";

            $this->pdo = new PDO($dsn, $user, $password);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo 'Erreur : '.$e->getMessage();
            die();
        }
    }

    public function findAll(): array
    {
        $query = "SELECT * FROM produit ORDER BY libelle";
        $statement = $this->pdo->prepare($query);
        $statement->execute();
        
        $produits = [];
        while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
            $data = [
                'id' => $row['id'],
                'libelle' => $row['libelle'],
                'prix' => (float)$row['prix'],
                'quantiteStock' => (int)($row['quantite_stock'] ?? 0)
            ];
            
            $produit = Produit::toObject($data);
            $produits[] = $produit;
        }
        
        return $produits;
    }
}