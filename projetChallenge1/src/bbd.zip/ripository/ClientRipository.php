<?php

namespace App\Ripository;

use App\Entity\Client;
use PDO;
use PDOException;

class ClientRipository
{
    private PDO $pdo;

    public function __construct()
    {
        try {
            $host = 'localhost';
            $dbname = 'Auchan';
            $user = 'postgres';
            $password = 'passer';

            $dsn = "pgsql:host=$host;dbname=$dbname";

            $this->pdo = new PDO($dsn, $user, $password);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo 'Erreur : '.$e->getMessage();
            die();
        }
    }

    public function findAll(): array
    {
        $query = "SELECT * FROM personne WHERE type = 'client'";
        $statement = $this->pdo->prepare($query);
        $statement->execute();
        
        $clients = [];
        while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
            $client = Client::toObject($row);
            $clients[] = $client;
        }
        
        return $clients;
    }
    
    
}